/*******************************************************************************
 * Copyright 2019-2021 Microchip FPGA Embedded Systems Solutions.
 *
 * SPDX-License-Identifier: MIT
 *
 * @file miv_rv32_init.c
 * @author Microchip FPGA Embedded Systems Solutions
 * @brief Mi-V soft processor memory section initializations and start-up code.
 *
 * SVN $Revision: 13158 $
 * SVN $Date: 2021-01-31 10:57:57 +0530 (Sun, 31 Jan 2021) $
 */

#include <unistd.h>

#ifdef __cplusplus
extern "C" {
#endif

extern void main(void);

void _init(void)
{
    /* This function is a placeholder for the case where some more hardware
     * specific initializations are required before jumping into the application
     * code. You can implement it here. */

    /* Jump to the application code after all initializations are completed */
    main();
}

/* Function called after main() finishes */
void
_fini(void)
{
}

#ifdef __cplusplus
}
#endif

