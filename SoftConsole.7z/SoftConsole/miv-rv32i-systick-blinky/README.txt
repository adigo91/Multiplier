
*******************************************************************************
                            miv-rv32i-systick-blinky
*******************************************************************************
This project demonstrates the Mi-V soft processor system timer interrupt 
functionality.

This is a minimal project which can be used with MIV_RV32 ip core as well as the
legacy RV32 ip cores.

There are total 6 different build configurations provided with this project 
which configure this SoftConsole project for different RISC-V instruction 
extension combinations. The Following configurations can be used with any of the 
Mi-V soft processors since they use only the base instruction set RV32I.
    miv32i-Debug
    miv32i-Release

Note: These configurations use microsemi-riscv-ram_imc.ld, so they will run 
MIV_RV32 core out-of-the-box. 

If you wish to run them on one of the legacy RV32 cores then change the linker
configuration to use microsemi-riscv-ram-ima.ld and make sure that the
"MIV_LEGACY_RV32" macro is defined in the project settings.

The following configurations can be used with the corresponding Mi-V cores on 
which the respective instruction extensions are enabled. You must make sure that 
the Mi-V core configurations and the SoftConsole project build configuration 
that you are using are compatible with each other.
    miv32ima-Debug
    miv32ima-Release
    miv32imc-Debug
    miv32imc-Release
    
______________________
Linker script changes 
______________________
You must make sure that in addition to the reset vector, all other memory address 
configurations in the Mi-V soft processor match with the memory layout defined 
in the linker script.

The MIV_RV32 cores provide Tightly Coupled Memory (TCM), it's start address is 
configurable (size = 256k). You can also download and execute code from the TCM. 
In this case you must make sure that the linker script is updated according to
the TCM configurations in your IP core. 

__________________________________
MACROs for conditional compilation 
__________________________________

MIV_LEGACY_RV32: 

Define this macro in the project settings (assembler and compiler) when
you are using one of the legacy RV32 cores (any combination of the supported ISA 
extension).

This macro must not be defined if you are using a MIV_RV32 core.

MIV_LEGACY_RV32_VECTORED_INTERRUPTS:

Enable this macro only in the **assembler properties** when you 
want to use vectored interrupts on legacy RV32 cores (any combination of the 
supported ISA extension).

C/C++ Build > Settings > Tool Settings > GNU RISC-V Cross Assembler > 
> Preprocessor > Defined Symbols

By default, all interrupts on legacy RV32 cores are treated as non-vectored
interrupts.    


MTIME and MTIMECMP:

MIV_RV32 core offers flexibility in terms of generating MTIME and MTIMECMP 
registers internal to the core or using external time reference. 
There are following 4 possible combinations:

1.  “Internal MTIME” and “Internal MTIME IRQ” enabled
    Generate the MTIME and MTIMECMP registers internally. 
    (This is the only combination available on legacy RV32 cores).

2.  “Internal MTIME” enabled and “Internal MTIME IRQ” disabled
    Generate the MTIME internally and have a timer interrupt input to the core 
    as external pin.  
    In this case 1 pin port will be available on MIV_RV32 for timer interrupt.
    
3.  “Internal MTIME” disabled and “Internal MTIME IRQ” enabled
    Generate the time value externally and generate the mtimecmp and interrupt 
    internally. 
    (for example a multiprocessor system with a shared time between all cores)
    In this case a 64 bit port will be available on the MIV_RV32 core as input.
    
4.  “Internal MTIME” and “Internal MTIME IRQ” disabled
    Generate both the time and timer interrupts externally.
    In this case a 64 bit port will be available on the MIV_RV32 core as input.
    and a 1 pin port will be available for timer interrupt. 

To handle all these combinations in the firmware, the following constants must be 
defined in accordance with the configuration that you have made on your 
MIV_RV32 core design.

MIV_RV32_EXT_TIMER
    When defined, it means that the MTIME register is not available internal to 
    the core. In this case a 64 bit port will be available on the MIV_RV32 core 
    as input. When this macro is not defined, it means that the MTIME register 
    is available internal to the core.
    
MIV_RV32_EXT_TIMECMP
    When defined, it means the MTIMECMP register is not available internally 
    to the core and the Timer interrupt input to the core comes as an external 
    pin. When this macro is not defined it means the that MTIMECMP register 
    exists internal to the core and that the timer interrupt is generated 
    internally.
    
    
**NOTE**
All These macros must not be defined when you are using legacy RV32 cores.
 
_______________________
hardware_platform.h
_______________________
The hardware_platform.h file must be updated as per the peripheral addresses in 
your Libero design.

Make sure that the processor clock is correctly configured using SYS_CLK_FREQ.

*******************************************************************************
*******************************************************************************

================================================================================
                    Systick Interrupt example project
================================================================================

This SoftConsole project is an example demonstration of configuring and using
the systick interrupt on any of the Mi-V core. 

The LEDs will toggle and a message will be displayed on UART terminal on every 
system timer interrupt.
--------------------------------------------------------------------------------
                                Target hardware
--------------------------------------------------------------------------------
This example project can be targeted to Mi-V designs available at
https://github.com/RISCV-on-Microsemi-FPGA/Hardware-Platforms

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                          Mi-V Core revision dependencies
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
The MIV_RV32 HAL v3.0 supports "MIV_RV32" as well as th "legacy RV32 IP cores".

The term "MIV_RV32" represents following two cores
 - MIV_RV32 v3.0 and later             (Latest and greatest Mi-V soft processor)

 - MIV_RV32IMC v2.1                    (MIV_RV32 v3.0 is a drop in replacement 
                                        for this core. It is recommended to 
                                        migrate your design to MIV_RV32 v3.0)

The term "legacy RV32 IP cores" represents following IP cores
MiV_RV32IMA_L1_AHB
MIV_RV32IMA_L1_AXI
MiV_RV32IMAF_L1_AHB

(These "legacy RV32 IP cores" will be discontinued in the near future. 
It is recommended to migrate designs to MIV_RV32 v3.0)

