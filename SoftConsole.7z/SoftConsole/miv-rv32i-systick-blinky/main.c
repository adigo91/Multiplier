/*******************************************************************************
 * Copyright 2019-2021 Microchip FPGA Embedded Systems Solutions.
 *
 * SPDX-License-Identifier: MIT
 *
 * Common example project which can run on all Mi-V soft processor variants.
 * Please refer README.TXT in the root folder of this project for more details.
 *
 */
#include <stdlib.h>
#include "miv_rv32_hal.h"
#include "hal.h"
#include "hw_platform.h"
#include "core_gpio.h"
#include "core_uart_apb.h"
#include "core_timer.h"


/*******************************************************************************
 * Copyright 2025 Microchip FPGA Embedded Systems Solutions.
 *
 * SPDX-License-License: MIT
 *
 * SoftConsole program for First_multi accelerator demo.
 */


/*******************************************************************************
 * Copyright 2025 Microchip FPGA Embedded Systems Solutions.
 *
 * SPDX-License-License: MIT
 *
 * SoftConsole program for First_multi accelerator demo.
 */


/*******************************************************************************
 * Copyright 2025 Microchip FPGA Embedded Systems Solutions.
 *
 * SPDX-License-License: MIT
 *
 * SoftConsole program for First_multi accelerator demo.
 */


const char *g_welcome_msg =
    "\r\n******************************************************************************\r\n\n\
********************    First_multi Accelerator Demo    ***********************\r\n\n\
******************************************************************************\r\n\r\n\
Enter hexadecimal inputs to compute S = A + B + C * (D + E).\r\n\
Press 'q' to quit.\r\n";

/* Buffer sizes */
#define RX_BUFF_SIZE 64u
#define UI_BUFF_SIZE 100u
#define OUTPUT_BUFF_SIZE 150u

/* UART instance data */
UART_instance_t g_uart;
uint8_t g_rx_buff[RX_BUFF_SIZE] = {0u};
volatile uint8_t g_rx_size = 0u;
uint8_t g_ui_buf[UI_BUFF_SIZE] = {0u};
uint8_t g_output_buf[OUTPUT_BUFF_SIZE] = {0u};

/* Structure matching the First_multi AXI target memory map */
struct first_mult {
    uint32_t run;        // Offset 0x00 (31:0)
    uint32_t result0;    // Offset 0x04 (63:32)
    uint32_t result1;    // Offset 0x08 (31:0)
    uint32_t result2;    // Offset 0x0C (63:32)
    uint32_t result3;    // Offset 0x10 (31:0)
    uint32_t A0;         // Offset 0x14 (63:32)
    uint32_t A1;         // Offset 0x18 (31:0)
    uint32_t B0;         // Offset 0x1C (63:32)
    uint32_t C0;         // Offset 0x20 (31:0)
    uint32_t D0;         // Offset 0x24 (63:32)
    uint32_t D1;         // Offset 0x28 (31:0)
    uint32_t E0;         // Offset 0x2C (63:32)
    uint32_t padding;    // Offset 0x30 (31:0) - Removed in hardware, kept for alignment
    uint32_t ctrl;       // Offset 0x38 (0:0 for slave_memory_ctrl, extended to 32 bits)
};

// Base address for First_multi AXI target
#define FIRST_MULT_BASE_ADDR 0x60000000UL

/*==============================================================================
 * Validate the input hex value.
 */
uint8_t validate_input_hex(uint8_t ascii_input) {
    return (((ascii_input >= 'A') && (ascii_input <= 'F')) ||
            ((ascii_input >= 'a') && (ascii_input <= 'f')) ||
            ((ascii_input >= '0') && (ascii_input <= '9'))) ? 1u : 0u;
}

/*==============================================================================
 * Function to read data from UART terminal and store it.
 */
uint16_t get_data_from_uart(uint8_t *dst_ptr, uint16_t dst_size, const uint8_t *msg, uint16_t msg_size) {
    uint8_t complete = 0u;
    uint8_t rx_buff[1];
    uint8_t rx_size = 0u;
    uint16_t count = 0u;

    UART_send(&g_uart, msg, msg_size);

    while (!complete) {
        rx_size = UART_get_rx(&g_uart, rx_buff, sizeof(rx_buff));
        if (rx_size > 0u) {
            if (rx_buff[0] == '\r' || rx_buff[0] == '\n') {
                dst_ptr[count] = '\0';
                count++;
                complete = 1u;
            } else if (rx_buff[0] == 0x08u) { // Backspace
                if (count > 0) count--;
            } else if (validate_input_hex(rx_buff[0]) != 1u) {
                UART_send(&g_uart, rx_buff, sizeof(rx_buff));
                const uint8_t error_msg[] = "\r\n Invalid input. Use 0-9, A-F, a-f.\r\n ";
                UART_send(&g_uart, error_msg, sizeof(error_msg));
                UART_send(&g_uart, msg, msg_size);
                complete = 0u;
            } else {
                dst_ptr[count] = rx_buff[0];
                count++;
                UART_send(&g_uart, rx_buff, sizeof(rx_buff));
                if (count == dst_size) complete = 1u;
            }
        }
    }
    return count;
}

// Read hex input from UART terminal as unsigned.
uint32_t get_user_input(const int8_t *msg, uint16_t msg_len) {
    uint8_t readbuf[UI_BUFF_SIZE];
    uint16_t size = UI_BUFF_SIZE - 1;
    uint16_t count = get_data_from_uart(readbuf, size, msg, msg_len);
    readbuf[count] = '\0';
    const uint8_t input_prefix[] = "\r\nInput: ";
    UART_send(&g_uart, input_prefix, sizeof(input_prefix) - 1);
    UART_send(&g_uart, readbuf, count);
    UART_send(&g_uart, (const uint8_t *)"\r\n", 2);
    return (uint32_t)strtoul(readbuf, NULL, 16); // Use strtoul for unsigned 32-bit
}

// Custom function to convert uint32_t to hex string
void uint32_to_hex_str(uint32_t value, uint8_t *buf, uint8_t buf_size) {
    uint8_t i = 0;
    uint8_t nibble;
    for (i = 0; i < 8 && i < buf_size - 1; i++) {
        nibble = (value >> (28 - (i * 4))) & 0xF;
        buf[i] = (nibble < 10) ? ('0' + nibble) : ('A' + (nibble - 10));
    }
    buf[i] = '\0';
}

// Run First_multi accelerator for a single input from the UART terminal and output the result.
void run_single_multiply() {
    struct first_mult fm = {0};

    // Get inputs from UART (now including D and E)
    fm.A0 = get_user_input("Enter A0 (lower 32 bits, hex): ", 29);
    fm.A1 = get_user_input("Enter A1 (upper 32 bits, hex): ", 29);
    fm.B0 = get_user_input("Enter B0 (hex): ", 16);
    fm.C0 = get_user_input("Enter C0 (hex): ", 16);
    fm.D0 = get_user_input("Enter D0 (lower 32 bits, hex): ", 29);
    fm.D1 = get_user_input("Enter D1 (upper 32 bits, hex): ", 29);
    fm.E0 = get_user_input("Enter E0 (hex): ", 16);

    // Build input message manually
    uint8_t input_msg[] = "Sending inputs (hex):\r\n"
                          "A: 0x";
    uint8_t hex_buf[9];
    uint32_to_hex_str(fm.A1, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, input_msg, sizeof(input_msg) - 1);
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)" 0x", 3);
    uint32_to_hex_str(fm.A0, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)"\r\nB: 0x", 7);
    uint32_to_hex_str(fm.B0, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)"\r\nC: 0x", 7);
    uint32_to_hex_str(fm.C0, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)"\r\nD: 0x", 7);
    uint32_to_hex_str(fm.D1, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)" 0x", 3);
    uint32_to_hex_str(fm.D0, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)"\r\nE: 0x", 7);
    uint32_to_hex_str(fm.E0, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)"\r\n", 2);

    UART_send(&g_uart, (const uint8_t *)"Writing inputs to First_multi accelerator over AXI\r\n", 48);
    volatile struct first_mult *fm_accel_addr = (volatile struct first_mult *)FIRST_MULT_BASE_ADDR;
    fm_accel_addr->A0 = fm.A0;
    UART_send(&g_uart, (const uint8_t *)"A0 written: 0x", 13);
    uint32_to_hex_str(fm_accel_addr->A0, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)"\r\n", 2);
    fm_accel_addr->A1 = fm.A1;
    UART_send(&g_uart, (const uint8_t *)"A1 written: 0x", 13);
    uint32_to_hex_str(fm_accel_addr->A1, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)"\r\n", 2);
    fm_accel_addr->B0 = fm.B0;
    UART_send(&g_uart, (const uint8_t *)"B0 written: 0x", 13);
    uint32_to_hex_str(fm_accel_addr->B0, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)"\r\n", 2);
    fm_accel_addr->C0 = fm.C0;
    UART_send(&g_uart, (const uint8_t *)"C0 written: 0x", 13);
    uint32_to_hex_str(fm_accel_addr->C0, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)"\r\n", 2);
    fm_accel_addr->D0 = fm.D0;
    UART_send(&g_uart, (const uint8_t *)"D0 written: 0x", 13);
    uint32_to_hex_str(fm_accel_addr->D0, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)"\r\n", 2);
    fm_accel_addr->D1 = fm.D1;
    UART_send(&g_uart, (const uint8_t *)"D1 written: 0x", 13);
    uint32_to_hex_str(fm_accel_addr->D1, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)"\r\n", 2);
    fm_accel_addr->E0 = fm.E0;
    UART_send(&g_uart, (const uint8_t *)"E0 written: 0x", 13);
    uint32_to_hex_str(fm_accel_addr->E0, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)"\r\n", 2);

    // Set run to trigger computation
    UART_send(&g_uart, (const uint8_t *)"Setting run to trigger computation\r\n", 36);
    fm_accel_addr->run = 1;
    UART_send(&g_uart, (const uint8_t *)"Waiting for First_multi accelerator to finish\r\n", 47);
    while (fm_accel_addr->run) {
        UART_send(&g_uart, (const uint8_t *)".", 1); // Debug dot
        for (volatile int i = 0; i < 100000; i++); // Smaller delay between checks
    }
    UART_send(&g_uart, (const uint8_t *)"\r\nDone waiting\r\n", 15);

    UART_send(&g_uart, (const uint8_t *)"Reading result from First_multi accelerator over AXI:\r\n", 54);
    fm.result0 = fm_accel_addr->result0;
    UART_send(&g_uart, (const uint8_t *)"Result0: 0x", 11);
    uint32_to_hex_str(fm.result0, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)"\r\n", 2);
    fm.result1 = fm_accel_addr->result1;
    UART_send(&g_uart, (const uint8_t *)"Result1: 0x", 11);
    uint32_to_hex_str(fm.result1, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)"\r\n", 2);
    fm.result2 = fm_accel_addr->result2;
    UART_send(&g_uart, (const uint8_t *)"Result2: 0x", 11);
    uint32_to_hex_str(fm.result2, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)"\r\n", 2);
    fm.result3 = fm_accel_addr->result3;
    UART_send(&g_uart, (const uint8_t *)"Result3: 0x", 11);
    uint32_to_hex_str(fm.result3, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)"\r\n", 2);

    // Rebuild result message manually for clarity
    const uint8_t result_prefix[] = "Result (hex): 0x";
    UART_send(&g_uart, result_prefix, sizeof(result_prefix) - 1);
    uint32_to_hex_str(fm.result3, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)" 0x", 3);
    uint32_to_hex_str(fm.result2, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)" 0x", 3);
    uint32_to_hex_str(fm.result1, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)" 0x", 3);
    uint32_to_hex_str(fm.result0, hex_buf, sizeof(hex_buf));
    UART_send(&g_uart, hex_buf, 8);
    UART_send(&g_uart, (const uint8_t *)"\r\n", 2);
}

void Init(void) {
    // Disable interrupts
    HAL_disable_interrupts();

    // Initialize CoreUARTapb
    UART_init(&g_uart, COREUARTAPB0_BASE_ADDR, BAUD_VALUE_115200, (DATA_8_BITS | NO_PARITY));

    // Enable interrupts and configure SysTick (as per corrected setup)
    HAL_enable_interrupts();
    MRV_systick_config(SYS_CLK_FREQ);
}

/*-------------------------------------------------------------------------//**
 * Main function.
 */
int main(void) {
    // Dummy interrupt handlers (required by HAL)
    void SysTick_Handler(void) {}
    void Software_IRQHandler(void) { MRV_clear_soft_irq(); }
    void External_IRQHandler(void) {}
    void MGEUI_IRQHandler(void) {}
    void MGECI_IRQHandler(void) {}
    void MSYS_EI0_IRQHandler(void) {}
    void MSYS_EI1_IRQHandler(void) {}
    void MSYS_EI2_IRQHandler(void) {}
    void MSYS_EI3_IRQHandler(void) {}
    void MSYS_EI4_IRQHandler(void) {}
    void MSYS_EI5_IRQHandler(void) {}
    void OPSRV_IRQHandler(void) {}

    Init();

    // Transmit welcome message
    UART_polled_tx_string(&g_uart, (const uint8_t *)g_welcome_msg);

    while (1) {
        g_rx_size = UART_get_rx(&g_uart, g_rx_buff, RX_BUFF_SIZE);
        if (g_rx_size > 0u) {
            if (g_rx_buff[0] == 'q' || g_rx_buff[0] == 'Q') {
                const uint8_t exit_msg[] = "\r\nExiting...\r\n";
                UART_send(&g_uart, exit_msg, sizeof(exit_msg) - 1);
                break;
            } else if (g_rx_buff[0] == '\r' || g_rx_buff[0] == '\n') {
                run_single_multiply();
            }
            g_rx_size = 0u; // Clear buffer for next input
        }
    }

    return 0u;
}
